﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}